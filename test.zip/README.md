# P2P Trades API (NestJS + SQLite)

API para registrar operaciones individuales (compra/venta) con:
- `type`: `buy` o `sell`
- `amount`: cantidad de USDT
- `rate`: Bs/USDT
- `additionalData`: JSON (por ejemplo IP, userAgent, referencia)
- `notes`: texto opcional

Incluye Swagger, Docker para desarrollo con watch y multi-stage para build/producción. Base de datos: SQLite.

## Cambios recientes

El modelo ahora guarda una sola operación por registro con `type` para poder filtrar compras y ventas por separado.

Si venías de una versión anterior (con `buyRate`/`sellRate`):
- En desarrollo, con `SYNC_DB=true`, TypeORM intentará sincronizar la tabla.
- Si tienes errores de esquema, elimina el archivo SQLite (`./data/dev.sqlite`) y se recreará.
- En producción considera usar migraciones.

## Endpoints

- `POST /api/v1/trades`
  - Body:
    ```json
    {
      "type": "buy",
      "amount": 66.04,
      "rate": 305.65,
      "additionalData": { "ip": "200.74.xx.xx", "userAgent": "Mozilla/5.0" },
      "notes": "Pago Móvil confirmado"
    }
    ```

- `GET /api/v1/trades?type=buy&limit=50&offset=0`
  - `type` es opcional (`buy` | `sell`). Si no se envía, lista todo.
  - Respuesta:
    ```json
    {
      "data": [ /* TradeRecord[] */ ],
      "meta": { "total": 1, "limit": 50, "offset": 0, "type": "buy" }
    }
    ```

- `GET /api/v1/trades/:id`

- `PATCH /api/v1/trades/:id`

- `DELETE /api/v1/trades/:id`

## Swagger

- UI: `http://localhost:3000/docs`
- Tag principal: `trades`
- Preparado para escalar (versionado por URL `/api/v1` y `autoLoadEntities`).

## Desarrollo (Docker con watch)

```
docker compose -f docker-compose.dev.yml up --build
```

- API: http://localhost:3000/api/v1/trades
- Swagger: http://localhost:3000/docs
- DB: `./data/dev.sqlite`
- Logs/errores en tiempo real en la consola.

Para detener:
```
docker compose -f docker-compose.dev.yml down
```

## Producción (Docker)

Construir imagen prod:
```
docker build -t p2p-trades-api:prod --target prod .
```

Correr:
```
docker run -it --rm -p 3000:3000 \
  -e NODE_ENV=production \
  -e PORT=3000 \
  -e SQLITE_DB_PATH=/usr/src/app/data/prod.sqlite \
  -e SYNC_DB=false \
  -e SWAGGER_ENABLED=true \
  -v $(pwd)/data:/usr/src/app/data \
  --name p2p-trades-api p2p-trades-api:prod
```

## Producción (PM2, sin Docker)

```
npm ci
npm run build
pm2 start ecosystem.config.js --env production
pm2 logs p2p-trades-api
```

## Notas

- No hay autenticación (por ahora).
- `additionalData` es JSON libre para adjuntar metadata (IP, userAgent, referencias internas).
- Si prefieres el nombre `aditionalData` (una sola "d"), se puede renombrar en DTO/entidad/controlador fácilmente.