import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsNumber, IsOptional, IsString, Min, IsObject } from 'class-validator';
import { TradeType } from '../entities/trade-record.entity';

export class CreateTradeDto {
  @ApiProperty({ enum: TradeType, enumName: 'TradeType', example: TradeType.BUY })
  @IsEnum(TradeType)
  type!: TradeType;

  @ApiProperty({ example: 66.04, description: 'Cantidad de USDT involucrada' })
  @IsNumber()
  @Min(0)
  amount!: number;

  @ApiProperty({ example: 305.65, description: 'Tasa (Bs/USDT) a la que se ejecutó la operación' })
  @IsNumber()
  @Min(0)
  rate!: number;

  @ApiPropertyOptional({
    example: { ip: '200.74.XX.XX', userAgent: 'Mozilla/5.0', ref: 'p2p-venta' },
    description: 'Objeto JSON con datos adicionales (IP, userAgent, referencia, etc.)',
  })
  @IsOptional()
  @IsObject()
  additionalData?: Record<string, any>;

  @ApiPropertyOptional({ example: 'Pago Móvil confirmado en 2 min', description: 'Notas opcionales' })
  @IsOptional()
  @IsString()
  notes?: string;
}