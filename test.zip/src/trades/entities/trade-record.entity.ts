import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';

export enum TradeType {
  BUY = 'buy',
  SELL = 'sell',
}

@Entity('trade_records')
export class TradeRecord {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  // Tipo de operación: compra (buy) o venta (sell)
  @Column({ type: 'text' })
  type!: TradeType;

  // Cantidad de USDT involucrada
  @Column({ type: 'real' })
  amount!: number;

  // Tasa en Bs/USDT a la que se ejecutó esta operación
  @Column({ type: 'real' })
  rate!: number;

  // Datos adicionales serializados (por ejemplo, IP, userAgent, etc.)
  // Usamos simple-json para almacenar un objeto JSON en SQLite
  @Column({ type: 'simple-json', nullable: true })
  additionalData?: Record<string, any> | null;

  // Notas opcionales
  @Column({ type: 'text', nullable: true })
  notes?: string | null;

  @CreateDateColumn({ type: 'datetime' })
  createdAt!: Date;

  @UpdateDateColumn({ type: 'datetime' })
  updatedAt!: Date;
}