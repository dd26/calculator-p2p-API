import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FindOptionsWhere, Repository } from 'typeorm';
import { TradeRecord, TradeType } from './entities/trade-record.entity';
import { CreateTradeDto } from './dto/create-trade.dto';
import { UpdateTradeDto } from './dto/update-trade.dto';

@Injectable()
export class TradesService {
  constructor(
    @InjectRepository(TradeRecord)
    private readonly repo: Repository<TradeRecord>,
  ) {}

  async create(dto: CreateTradeDto): Promise<TradeRecord> {
    const rec = this.repo.create(dto);
    return this.repo.save(rec);
  }

  async findAll(params: { limit?: number; offset?: number; type?: TradeType } = {}) {
    const limit = Math.min(Math.max(params.limit ?? 50, 1), 200);
    const offset = Math.max(params.offset ?? 0, 0);

    const where: FindOptionsWhere<TradeRecord> = {};
    if (params.type) where.type = params.type;

    const [data, total] = await this.repo.findAndCount({
      where,
      take: limit,
      skip: offset,
      order: { createdAt: 'DESC' },
    });

    return {
      data,
      meta: { total, limit, offset, type: params.type ?? null },
    };
  }

  async findOne(id: string): Promise<TradeRecord> {
    const rec = await this.repo.findOne({ where: { id } });
    if (!rec) throw new NotFoundException('TradeRecord not found');
    return rec;
  }

  async update(id: string, dto: UpdateTradeDto): Promise<TradeRecord> {
    const rec = await this.findOne(id);
    Object.assign(rec, dto);
    return this.repo.save(rec);
  }

  async remove(id: string): Promise<void> {
    const rec = await this.findOne(id);
    await this.repo.remove(rec);
  }
}