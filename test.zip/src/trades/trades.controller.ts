import {
  Controller,
  Get,
  Post,
  Body,
  Query,
  Param,
  Patch,
  Delete,
  ParseIntPipe,
  ParseEnumPipe,
} from '@nestjs/common';
import { ApiCreatedResponse, ApiOkResponse, ApiQuery, ApiTags } from '@nestjs/swagger';
import { TradesService } from './trades.service';
import { CreateTradeDto } from './dto/create-trade.dto';
import { UpdateTradeDto } from './dto/update-trade.dto';
import { TradeRecord, TradeType } from './entities/trade-record.entity';

@ApiTags('trades')
@Controller({ path: 'trades', version: '1' })
export class TradesController {
  constructor(private readonly service: TradesService) {}

  @Post()
  @ApiCreatedResponse({ type: TradeRecord, description: 'Registro de trade creado' })
  create(@Body() dto: CreateTradeDto) {
    return this.service.create(dto);
  }

  @Get()
  @ApiOkResponse({ description: 'Lista de registros con paginación y filtro por tipo' })
  @ApiQuery({ name: 'type', required: false, enum: TradeType, example: 'buy' })
  @ApiQuery({ name: 'limit', required: false, example: 50 })
  @ApiQuery({ name: 'offset', required: false, example: 0 })
  findAll(
    @Query('type', new ParseEnumPipe(TradeType, { optional: true })) type?: TradeType,
    @Query('limit', new ParseIntPipe({ optional: true })) limit?: number,
    @Query('offset', new ParseIntPipe({ optional: true })) offset?: number,
  ) {
    return this.service.findAll({ type, limit, offset });
  }

  @Get(':id')
  @ApiOkResponse({ type: TradeRecord })
  findOne(@Param('id') id: string) {
    return this.service.findOne(id);
  }

  @Patch(':id')
  @ApiOkResponse({ type: TradeRecord })
  update(@Param('id') id: string, @Body() dto: UpdateTradeDto) {
    return this.service.update(id, dto);
  }

  @Delete(':id')
  @ApiOkResponse({ description: 'Eliminado' })
  remove(@Param('id') id: string) {
    return this.service.remove(id);
  }
}