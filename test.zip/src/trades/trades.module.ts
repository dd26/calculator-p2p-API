import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TradesController } from './trades.controller';
import { TradesService } from './trades.service';
import { TradeRecord } from './entities/trade-record.entity';

@Module({
  imports: [TypeOrmModule.forFeature([TradeRecord])],
  controllers: [TradesController],
  providers: [TradesService],
  exports: [],
})
export class TradesModule {}