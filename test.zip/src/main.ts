import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe, VersioningType } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Prefijo global para escalar a múltiples controladores/módulos
  app.setGlobalPrefix('api');

  // Versionado listo para el futuro (URL versioning)
  app.enableVersioning({
    type: VersioningType.URI,
    defaultVersion: '1',
  });

  // Validaciones globales
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      transformOptions: { enableImplicitConversion: true },
    }),
  );

  app.enableCors();

  // Swagger escalable
  if (process.env.SWAGGER_ENABLED !== 'false') {
    const config = new DocumentBuilder()
      .setTitle('P2P Trades API')
      .setDescription('API simple para registrar y consultar trades (sin autenticación por ahora).')
      .setVersion('1.0.0')
      .addTag('trades', 'Operaciones de compra/venta (registro de tasas y cantidades)')
      .build();

    const document = SwaggerModule.createDocument(app, config, {
      // Permite escalar: incluir múltiples módulos/controladores a futuro
      deepScanRoutes: true,
    });
    SwaggerModule.setup('docs', app, document);
  }

  const port = process.env.PORT ? Number(process.env.PORT) : 3000;
  await app.listen(port);
  // eslint-disable-next-line no-console
  console.log(`Server running on http://localhost:${port} (docs: /docs)`);
}
bootstrap();