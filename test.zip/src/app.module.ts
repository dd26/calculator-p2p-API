import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TradesModule } from './trades/trades.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    TypeOrmModule.forRootAsync({
      useFactory: () => ({
        type: 'sqlite',
        database: process.env.SQLITE_DB_PATH || './data/dev.sqlite',
        autoLoadEntities: true, // escalable: carga automática de entidades desde los módulos
        synchronize: process.env.SYNC_DB !== 'false', // solo true en dev
        logging: process.env.TYPEORM_LOGGING === 'true',
      }),
    }),
    TradesModule,
  ],
})
export class AppModule {}