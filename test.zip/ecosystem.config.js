module.exports = {
  apps: [
    {
      name: "p2p-trades-api",
      script: "dist/main.js",
      instances: 1,
      exec_mode: "fork",
      watch: false,
      env: {
        NODE_ENV: "production",
        PORT: 3002,
        SQLITE_DB_PATH: "./data/prod.sqlite",
        SYNC_DB: "false",
        SWAGGER_ENABLED: "true",
        TYPEORM_LOGGING: "false"
      }
    }
  ]
};